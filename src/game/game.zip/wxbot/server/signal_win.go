// +build windows

package server

import (
	"os"
)

func OnSignal(sig os.Signal) {

}
