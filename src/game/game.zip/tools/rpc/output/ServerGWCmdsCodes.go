package cmds
import ()

const (
	ServerGWCmds_HEART_BEAT = 0 // 心跳
	ServerGWCmds_LOGIN_GUEST = 10001 // 登录
	ServerGWCmds_LOGIN_PLATFORM = 10002 // 登录(ptID平台）
	
)