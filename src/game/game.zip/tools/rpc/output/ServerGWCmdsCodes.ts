class ServerGWCmdsCodes
{
	public static HEART_BEAT:number = 0; // 心跳
	public static LOGIN_GUEST:number = 10001; // 登录
	public static LOGIN_PLATFORM:number = 10002; // 登录(ptID平台）
	
}