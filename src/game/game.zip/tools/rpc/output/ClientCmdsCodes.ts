class ClientCmdsCodes
{
	public static HEART_BEAT:number = 0; // 心跳
	public static LOGIN_SUCCESS:number = 1; // 登录成功
	public static LOGIN_FAILED:number = 2; // 登录失败（1 用户不存在，2  密码错误， 3 禁止登陆）
	
}