package server

type WebConfig struct {
	ServerVersion string
	ServerPort    int
	StaticDir     string
	WeiAppid 	  string
	WeiSecret     string
	WeiApiUrl     string
}
