package main

import (
	center "game/center"
)

func main() {
	center.Run()
}
