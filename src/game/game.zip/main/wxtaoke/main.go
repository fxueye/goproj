package main

import (
	wxtaoke "game/wxtaoke"
)

func main() {
	wxtaoke.Run()
}
