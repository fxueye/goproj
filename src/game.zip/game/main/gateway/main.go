package main

import (
	gateway "game/gateway"
)

func main() {
	gateway.Run()
}
