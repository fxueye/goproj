package main

import (
	wxbot "game/wxbot"
)

func main() {
	wxbot.Run()
}
