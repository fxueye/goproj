package main

import (
	web "game/web"
)

func main() {
	web.Run()
}
