package cmds
import ()

const (
	ServerCSCmds_GW_PING = 22001 // gw心跳
	ServerCSCmds_LOGINGUEST = 22004 // 登录
	
)