class ServerCSCmdsCodes
{
	public static GW_PING:number = 22001; // gw心跳
	public static LOGINGUEST:number = 22004; // 登录
	
}